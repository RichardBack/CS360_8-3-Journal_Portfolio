package com.zybooks.last_try_module_7_final_project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button updateButton = findViewById(R.id.button_update_item);
        Button viewButton = findViewById(R.id.button_view_items);

        updateButton.setOnClickListener(view -> {
            // GO to UpdateItemActivity
            Intent intent = new Intent(MainActivity.this, UpdateItemActivity.class);
            startActivity(intent);
        });

        viewButton.setOnClickListener(view -> {
            // Go to ItemGridActivity
            Intent intent = new Intent(MainActivity.this, ItemGridActivity.class);
            startActivity(intent);
        });
    }
}
